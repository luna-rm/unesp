para executar o arquivo em c eh necessario referenciar lWinmm
durante a programacao nos apenas conseguimos fazer essa referencia criando o excutavel a partir do comando "gcc main.c -o main.exe -lWinmm" no terminal
por isso estamos encaminhando o executavel tambem

agradecemos desde ja <3

> Camila Cristina Silva
> Pedro Ricieri Marchi 
