feito por: Pedro Ricieri Marchi
compilador: MinGW - compilado em um vscode 
sistema operacional: Windows 11