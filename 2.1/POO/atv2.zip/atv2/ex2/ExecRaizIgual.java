package ex2;

public class ExecRaizIgual extends Exception {
    public String toString() {
        return "Duas raizes iguais!";
    }
}