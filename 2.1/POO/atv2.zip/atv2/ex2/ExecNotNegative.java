package ex2;

public class ExecNotNegative extends Exception {
    public String toString() {
        return "Delta deu Negativo!";
    }
}